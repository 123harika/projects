package opr;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class ResponseServlet
 */
@WebServlet("/response")
public class response extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public response() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unused")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Integer result=(Integer)request.getAttribute("result");
		RequestDispatcher rd=request.getRequestDispatcher("/client.html");
		if(result==null) {
			rd.forward(request, response);
			return;
		}
		try {
			response.setContentType("text/html");
			
			PrintWriter out=response.getWriter();
			String op=(String)request.getAttribute("operation");
			out.println(op+"Result: <b>"+result.intValue()+"<br><br/>");
			rd.include(request, response);
			
		}
		catch(Exception e) {
			
		};
		
			
			
		}
}
