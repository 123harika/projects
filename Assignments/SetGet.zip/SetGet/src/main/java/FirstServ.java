
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;

/**
 * Servlet implementation class FirstServ
 */
@SuppressWarnings("serial")
@WebServlet("/FirstServ")
public class FirstServ extends GenericServlet {
	@SuppressWarnings("removal")
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
//Creating ServletContext object
		ServletContext servCon = getServletContext();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("Using ServletContext object to set and read context attributes");
//Setting Request Attributes to be shared between multiple servlets
		servCon.setAttribute("Name", request.getParameter("username"));
		servCon.setAttribute("Percent", request.getParameter("percentile"));
		
		if (new Integer((int) servCon.getAttribute("Percent")) < 90) {
			RequestDispatcher reqDispatch = servCon.getRequestDispatcher("/SecondServ");
			reqDispatch.forward(request, response);
		} else {
			RequestDispatcher reqDispatch = servCon.getRequestDispatcher("/ThirdServ");
			reqDispatch.forward(request, response);
		}
	}
}
