

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SecondServ
 */
@SuppressWarnings("serial")
@WebServlet("/SecondServ")
public class SecondServ extends GenericServlet
{
public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException
{
ServletContext servCon = getServletContext();
response.setContentType("text/html");
PrintWriter out = response.getWriter();

out.println("<b>" + "Hello " + servCon.getAttribute("Name") + "," + "</b>");
out.println("<br/>");
out.println("<br/>");
out.println("<br/>");
out.println("<br/>");
out.println("<b>Sorry, you are not eligible to get a scholarship at our university </b>");
out.println("<b>, because your percentage of " + servCon.getAttribute("Percent ") + " does not meet our criteria.<b>");

}
}
