

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


/**
 * Servlet implementation class Validate
 */
@WebServlet("/ValidateServlet")

public class Validate extends HttpServlet {

  protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
   {
      response.setContentType("text/html;charset=UTF-8");
      
      String name = request.getParameter("user");
      String pass = request.getParameter("pass");
      
      if(pass.equals("hari"))
      {
          //creating a session
          HttpSession session = request.getSession();
          session.setAttribute("user", name);
          response.sendRedirect("Welcome");
      }
  }
}

